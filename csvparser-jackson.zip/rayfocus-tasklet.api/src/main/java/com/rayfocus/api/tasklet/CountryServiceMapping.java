package com.rayfocus.api.tasklet;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class CountryServiceMapping {
	@JsonProperty("Country")
	private String country;
	
	@JsonProperty("Country code")
	private String countryCode;
	
	@JsonProperty("Language (current)")
	private String language;
	
	@JsonProperty("Lang code (current)")
	private String languageCode;
	
	@JsonProperty("Personal LaserJet label (postal)")
	private String personalLaserjetLabelPostal;
	
	@JsonProperty("Personal LaserJet label (UPS)")
	private String personalLaserjetLabelUPS;
	
	@JsonProperty("Business LaserJet label (postal)")
	private String businessLaserjetLabelPostal;
	
	@JsonProperty("Business LaserJet label (UPS)")
	private String businessLaserjetLabelUPS;

}
