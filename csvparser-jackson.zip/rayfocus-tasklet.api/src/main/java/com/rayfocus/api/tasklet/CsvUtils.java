package com.rayfocus.api.tasklet;

import java.io.File;
import java.io.FileInputStream;
import java.util.Collections;
import java.util.List;

import org.springframework.core.io.ClassPathResource;

import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;

public class CsvUtils {
	private static final CsvMapper mapper = new CsvMapper();

	public static <T> List<T> read(Class<T> clazz, String fileName) {
		try {
			File file = new ClassPathResource(fileName).getFile();
			CsvSchema schema = mapper.schemaFor(clazz).withHeader().withColumnReordering(true);
			ObjectReader reader = mapper.readerFor(clazz).with(schema);
			return reader.<T>readValues(new FileInputStream(file)).readAll();
		} catch (Exception e) {
			System.out.println("Error occurred while loading object list from file " + fileName);
			return Collections.emptyList();
		}
	}
}
