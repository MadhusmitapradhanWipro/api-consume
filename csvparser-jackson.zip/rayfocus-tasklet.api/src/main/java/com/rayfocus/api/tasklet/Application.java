package com.rayfocus.api.tasklet;

import java.io.IOException;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {

	public static void main(String[] args) throws IOException {
		SpringApplication.run(Application.class, args);

		List<CountryServiceMapping> cntServiceList = CsvUtils.read(CountryServiceMapping.class,
				"cycleon-country-mapping.csv");
		String countryCode = "";
		for (CountryServiceMapping mapping : cntServiceList) {
			System.out.println(mapping.toString());
			if (mapping.getCountryCode().equalsIgnoreCase("dk")) {
				countryCode = mapping.getPersonalLaserjetLabelPostal();
				System.out.println("*****" + countryCode);
				break;
			}
		}

		List<CountryPrdMapping> cntPrdList = CsvUtils.read(CountryPrdMapping.class, "cycleon-product-mapping.csv");

		for (CountryPrdMapping mapping : cntPrdList) {
			System.out.println(mapping.toString());
			if (mapping.getCode().equalsIgnoreCase(countryCode)) {
				System.out.println("*****" + mapping.getItemTypeRefStr());
				break;
			}
		}

	}

	/*
	 * public <T> List<T> loadObjectList(Class<T> type, String fileName) { try {
	 * CsvMapper mapper = new CsvMapper(); CsvSchema bootstrapSchema =
	 * CsvSchema.emptySchema().withSkipFirstDataRow(true); File file = new
	 * ClassPathResource(fileName).getFile(); System.out.println("File exist: " +
	 * file.exists()); MappingIterator<T> readValues =
	 * mapper.reader(type).with(bootstrapSchema).readValues(file); return
	 * readValues.readAll(); } catch (Exception e) {
	 * System.out.println("Error occurred while loading object list from file " +
	 * fileName); return Collections.emptyList(); } }
	 */
}
