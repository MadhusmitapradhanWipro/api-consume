package com.rayfocus.api.tasklet;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class CountryPrdMapping {
	@JsonProperty("CODE")
	private String code;

	@JsonProperty("Client #")
	private String clientNo;

	@JsonProperty("Client reference string")
	private String clientRefStr;

	@JsonProperty("FrontEnd #")
	private String frontEndNo;

	@JsonProperty("FrontEnd reference string")
	private String frontEndRefStr;

	@JsonProperty("ParcelType #")
	private String parcelTypeNo;

	@JsonProperty("ParcelType reference string")
	private String parcelRefStr;

	@JsonProperty("ItemType #")
	private String itemTypeNo;

	@JsonProperty("ItemType reference string")
	private String itemTypeRefStr;

}
